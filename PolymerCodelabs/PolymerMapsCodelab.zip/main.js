var element = document.querySelector(".content");
for (var i = 0; i < 200; i++) {
  element.innerText += "Hello, world!\n";
}
